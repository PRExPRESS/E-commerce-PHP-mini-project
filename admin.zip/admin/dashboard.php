<?php $orders=300;
    $percent=100;
    $expense=400000;
    $exPer=26;
    $users=134353;
    $income=2003443;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="CSS/dash.css">
    <script src="https://kit.fontawesome.com/4004d8d0ba.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="containver-fluid p-2">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
            </ol>
        </nav>
        <div class="row ml-1 mr-1">
            <div class=" col-3 card">
                <span>New Orders</span>
                    <i class="fas fa-shopping-cart"></i><br/>
                    <span class="od">
                        <?php echo $orders;?>
                    </span><br/>
                    <span>
                    <?php echo $percent."%"; ?>
                </span>
            </div>
            <div class="col-3 card">
                <span>Total Income</span>
                <i class="fas fa-hand-holding-usd"></i><br/>
                <span class="od">
                    <?php echo "$".$income;?>
                </span><br/>
                <span>
                <?php echo $exPer."%"; ?>
                </span>
            </div>
            <div class="card col-3">
                <span>Total Expenses</span>
                <i class="fas fa-file-invoice-dollar"></i><br/>
                <span class="od">
                    <?php echo "$".$expense;?>
                </span><br/>
                <span>
                <?php echo $exPer."%"; ?>
                </span>
            </div>
            <div class="card col-3">
                <span>Total User</span>
                <i class="fas fa-user-circle"></i><br/>
                <span class="od">
                    <?php echo $users;?>
                </span><br/>
                <span>
                <?php echo "Earn". $exPer."%"; ?>
                </span>
            </div>
        </div>
    </div>
    
    
    
</body>
</html>