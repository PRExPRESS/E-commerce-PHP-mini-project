<?php 
session_start();
include "connection.php" ?>
<?php 
    //form submission check
    if(isset($_POST['submit'])){
        $errors = array();
        //check if the username password entered
        if(!isset($_POST['username']) || strlen(trim($_POST['username']))<1){
            $errors[] = 'Username is Missing /Invalied';
        }
        if(!isset($_POST['passwd']) || strlen(trim($_POST['passwd']))<1){
            $errors[] = 'passwd is Missing /Invalied';
        }

        //check if there any error
        if(empty($errors)){
            //save username password into variabel
            $username = mysqli_real_escape_string($connection,$_POST['username']);
            $passwd = mysqli_real_escape_string($connection,$_POST['passwd']);
            //$hashed_passwd = sha1($passwd);
            
            //prepare database query
            $query = "SELECT * FROM admin 
                        WHERE username ='{$username}'
                        AND password = '{$passwd}' 
                        LIMIT 1 ";
            $result_set = mysqli_query($connection,$query);

            //check if  the user is valied
            if($result_set){
                //query succsesfull
                if(mysqli_num_rows($result_set)==1){
                    //valid user found
                   $user =mysqli_fetch_assoc($result_set);
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['first_name'] = $user['first_Name'];
                    //redirect to home page
                    header('Location:home.php');
                }else{
                    //username and password invalid
                    $errors[] = 'Invalid Username or Password';
                }
            }else{
                $errors[] = 'Database query faild';
            }
            
            //if not, display the error

        }
    }
?>
<?php 
if(!empty($errors)){
    echo '<script> alert("Username or Password Incorrect!")</script>'; 
    header('Location:index.php');

}

mysqli_close($connection) 
?>