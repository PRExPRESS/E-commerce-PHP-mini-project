<?php
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $dbname ="cms";

    $con = mysqli_connect('localhost','root','','xpresspc');

    if(mysqli_connect_errno()){
        die("Database Connection Failed".mysqli_connect_error());
    }






?>