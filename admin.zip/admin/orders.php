<?php
include 'head.php';
include 'connection.php';

$order_list = "";
//Query===================================
$query = "SELECT * FROM orders";
$get_list = mysqli_query($con,$query);
if ($get_list) {
  
  //echo '<script> alert(" Product add Successfully!")</script>';
  while ($order = mysqli_fetch_assoc($get_list)) {
    $order_list = "<tr>";
    $order_list .= "<td>";
    $order_list .= "{$order['order_id']}";
    $order_list .= "</td>";
    $order_list .= "<td>";
    $order_list .= "{$order['date']}";
    $order_list .= "</td>";
    $order_list .= "<td>";
    $order_list .= "{$order['product_name']}";
    $order_list .= "</td>";
    $order_list .= "<td>";
    $order_list .= "{$order['email']}";
    $order_list .= "</td>";
    $order_list .= "<td>";
    $order_list .= "{$order['price']}";
    $order_list .= "</td>";
    $order_list .= "<td>";
    $order_list .= "{$order['address']}";
    $order_list .= "</td>";
    $order_list .= "</tr>";

  }
}

  
  
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders</title>
</head>
<body>
    


    <header>
        <?php include "header.php"?>
    </header>
    <section class="row">
        <div class="col-2">
            <?php include "sidebar.php"?>
        </div>
        <div class=" col-10 container">
            <nav  aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Orders</li>
                </ol>
            </nav>
            <table class="table  ">
                <tr>
                    <th>Order_ID</th>
                    <th>Date</th>
                    <th>Product</th>
                    <th>Cust_email</th>
                    <th>Price</th>
                    <th>Shipping_Addres</th>
                </tr>
                <?php echo $order_list ?>
            
            </table>
        </div>
    
       
        
    </section>
    
    
</body>
</html>