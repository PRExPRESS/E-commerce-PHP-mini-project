-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 07, 2021 at 05:59 PM
-- Server version: 5.7.11
-- PHP Version: 7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `xpresspc`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `username` char(25) DEFAULT NULL,
  `email` char(100) DEFAULT NULL,
  `password` char(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `username`, `email`, `password`) VALUES
(7, 'prexpress', 'amprashmika1231@gmail.com', '7e72a607cb00a6c6c198425140c92d2f349d0082'),
(8, 'SRasadya', 'srasadya@gmail.com', '3ec7c3f064abf0d72eafb94790355826f02d5949'),
(10, 'Jane', 'jane@gmail.com', 'b44dda1dadd351948fcace1856ed97366e679239');

-- --------------------------------------------------------

--
-- Table structure for table `cust_details`
--

CREATE TABLE `cust_details` (
  `id` int(11) NOT NULL,
  `full_name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `birthday` varchar(200) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `address` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cust_details`
--

INSERT INTO `cust_details` (`id`, `full_name`, `email`, `contact`, `birthday`, `gender`, `address`) VALUES
(5, 'Pasindu Rashmika', 'amprashmika1231@gmail.com', '+94766746922', '2021-03-18', 'male', 'Horathapola , Welipennagahamulla,60200');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `date` date NOT NULL,
  `cust_name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `price` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `product_name`, `date`, `cust_name`, `email`, `address`, `price`) VALUES
(6, 'Acer Nitro 5 Core I5 10th Gen,144hz, Gaming Laptop', '2021-03-07', ' Pasindu Rashmika', 'amprashmika1231@gmail.com', ' Horathapola,Welipannagahamulla Kuliyapitiya 60240', '500'),
(8, 'MSI GF63 Thin I7 GAMING GTX1650', '2021-03-07', 'Sathsanduni Rasadya', 'srasadya@gmail.com', 'Horathapola , WelipennagahamullaKuliyapitiya60200', '700');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `modal` varchar(200) NOT NULL,
  `disc` varchar(1000) NOT NULL,
  `price` varchar(200) NOT NULL,
  `qty` int(11) NOT NULL,
  `status` varchar(20) NOT NULL,
  `img` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `modal`, `disc`, `price`, `qty`, `status`, `img`) VALUES
(4, 'Acer Nitro 5 Core I5 10th Gen,144hz, Gaming Laptop', '* IntelÂ® Coreâ„¢ i5-10300H (2.2 GHz Up to 4.3GHZ) 9MB L3\r\n\r\n* 8GB DDR4-2666 SDRAM (1x 8 GB) Supports Up to 32GB\r\n\r\n* NVIDIAÂ® GeForceÂ® GTX 1650 (4GB dedicated) Graphics\r\n\r\n* 256GB NVME + 1TB HDD Drive\r\n\r\n* 15.6" diagonal Thin Bezel Full HD IPS 144HZ(1920 x 1080)Display\r\n\r\n* Full-size keyboard with numeric keypad 4 Color\r\n\r\n* anti-ghosting, multi-touch touchpad\r\n\r\n* Dolby Digital Ultra Premium Audio\r\n\r\n* Duel Cooling System With Cooler Boost\r\n\r\n* 3 x USB 3.2 Gen 1, USB-C 3.2, HDMI,Mic In H/P Jack,LAN\r\n\r\n* Bluetooth 5.0, Killer Wireless,Gigabit Ethernet, 802.11ac\r\n\r\n* Genuine Windows 10 Licence 64 Bit Licence\r\n\r\n* 2 Year Comprehensive Warranty + 2 Year Service', '500', 2, 'available', 'nitro 5.jpg'),
(7, 'HP Spectre X360 i7 10th Gen, Gem Cut 2020 Ultrabook', '* IntelÂ® Coreâ„¢ i7-1065G7 (1.8GHz Up to 4.6GHZ) 8MB L3\r\n\r\n* 8GB DDR4-2666 SDRAM (2 x 8GB)\r\n\r\n* 32GB Intel Optane Memory\r\n\r\n* Intel Iris Plus Graphics\r\n\r\n* 512GB NVME SSD Drive\r\n\r\n* 13.3" diagonal Full HD IPS Micro-edge WLED-backlit touch screen\r\n\r\n* 360 Degree Rotatable Display\r\n\r\n* Full-size island-style backlit keyboard,HP Imagepad touch gesture \r\n\r\n* Fingerprint Reader\r\n\r\n* Bang & Olufsen; quad speakers; HP Audio Boost 2.0\r\n\r\n* Combo Audio Jack,Type C,Thunder Bolt 3,HP Sleep Charge\r\n\r\n* Bluetooth 5.0,IntelÂ® Wireless-AC 9560\r\n\r\n* Premium Build Metalic Build Quality,Gem Cut\r\n\r\n* Genuine Windows 10 Licence 64 Bit Licence\r\n\r\n* 1 Year Comprehensive Warranty + 2 Year Service', '600', 3, 'available', 'HP Spectre X360.jpg'),
(8, 'HP Probook 450 G7 Core I7 10th Gen Laptop', '* IntelÂ® Coreâ„¢ i7-10510U (1.6GHz Up to 4.2GHZ) 8MB L3\r\n\r\n* 8GB DDR4-2666 SDRAM (1 x 8GB) Supports Up to 32GB\r\n\r\n* 2GB Drdicated Nvidia G-FORCE MX230\r\n\r\n* 1TB HDD Drive + M.2 Slot\r\n\r\n* 15.6 "Full HD LED Display ( 1920 x 1080 )\r\n\r\n* Full-size, spill-resistant keyboard\r\n\r\n* Fingerprint Reader,HP 3D Drive Gaurd\r\n\r\n* Combo Audio Jack,Type C,USB 3.0,HDMI,Micro sd Reader\r\n\r\n* IntelÂ® Dual Band Wireless-802.11a/b/g/n/ac Wi-FiÂ® and BluetoothÂ®\r\n\r\n* Bluetooth 5.0, Fast Ethernet,HD Webcam,Duel Microphone\r\n\r\n* Optional Windows 10\r\n\r\n* 3 Years Comprehensive Warranty + 2 Year Service', '600', 2, 'available', 'HP Probook 450.png'),
(9, 'MSI GF63 Thin I7 GAMING GTX1650', '* IntelÂ® Coreâ„¢ i7-10750H (2.4 GHz Up to 4.6GHZ) 12MB L3\r\n\r\n* 8 GB DDR4-2666 SDRAM (1 x 8 GB) Supports Up to 32GB\r\n\r\n* NVIDIAÂ® GeForceÂ® GTX 1650i (4GB dedicated) Graphics\r\n\r\n* 512GB NVME SSD\r\n\r\n* 15.6" diagonal Full HD IPS (1920 x 1080) Thin Bezel Display\r\n\r\n* Full-size keyboard with numeric keypad Red Backlit\r\n\r\n* anti-ghosting, multi-touch touchpad\r\n\r\n* MSI Audio Boost, Nahimic 3 sound technology\r\n\r\n* 3 x USB 3.2 Gen 1, USB-C 3.2, HDMI,Mic In H/P Jack,LAN\r\n\r\n* Bluetooth 5.0, Fast Ethernet, Gigabit Ethernet, 802.11ac\r\n\r\n* Genuine Windows 10 Licence 64 Bit Licence\r\n\r\n* 2 Years Comprehensive Warranty + 2 Year Service', '700', 3, 'available', 'msi gf63 thin.jpg'),
(12, 'MSi G65 Stealth Thin 9th Gen I7,RTX 2070', '\r\n* IntelÂ® Coreâ„¢ i7-9750H (2.2 GHz Up to 4.5GHZ) 12MB L3\r\n\r\n* 16GB DDR4-2666 SDRAM (1 x 8 GB) Supports Up to 32GB\r\n\r\n* NVIDIAÂ® GeForceÂ® RTX 2070 (8GB dedicated) Graphics\r\n\r\n* 1TB NVME SSD Drive\r\n\r\n* 15.6" diagonal Full HD IPS 240HZ (1920 x 1080) Thin Bezel Display\r\n\r\n* Pre Key Steel Series keyboard with numeric keypad\r\n\r\n* anti-ghosting, multi-touch touchpad\r\n\r\n* Cooler Booster 5 Cooling System\r\n\r\n* Dyna Audio High Resolution Sounds 360 Suroound\r\n\r\n* Ultra Thin Light Weight 1.7 LBS\r\n\r\n* 3 x USB 3.2 Gen 1, USB-C 3.2, HDMI,Mic In H/P Jack,LAN', '2000', 1, 'available', 'msi gf63 thin.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `name`) VALUES
(1, '50g.jpg'),
(2, '50g.jpg'),
(3, '50g.jpg'),
(4, '50g.jpg'),
(5, '50g.jpg'),
(6, '50g.jpg'),
(7, '50g.jpg'),
(8, '50g.jpg'),
(9, '50g.jpg'),
(10, '50g.jpg'),
(11, '50g.jpg'),
(12, '50g.jpg'),
(13, '50g.jpg'),
(14, '50g.jpg'),
(15, '50g.jpg'),
(16, '50g.jpg'),
(17, '50g.jpg'),
(18, '50g.jpg'),
(19, '50g.jpg'),
(20, '50g.jpg'),
(21, '50g.jpg'),
(22, '50g.jpg'),
(23, '50g.jpg'),
(24, '50g.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `first_Name` varchar(100) NOT NULL,
  `last_Name` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `last_login` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `first_Name`, `last_Name`, `password`, `last_login`) VALUES
(4, 'srasadya@gmail.com', 'Sathsanduni', 'Rasadya', '3ec7c3f064abf0d72eafb94790355826f02d5949', '2021-03-07 11:41:22'),
(5, 'amprashmika1231@gmail.com', 'Pasindu', 'Rashmika', '7e72a607cb00a6c6c198425140c92d2f349d0082', '2021-03-07 12:16:39'),
(8, 'pasi@gmail.com', 'pasindu', 'Adhikari', '7e72a607cb00a6c6c198425140c92d2f349d0082', '2021-03-07 22:42:34');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cust_details`
--
ALTER TABLE `cust_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `cust_details`
--
ALTER TABLE `cust_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
