<?php session_start(); ?>
<?php include "connection.php"?>
<?php include "functions.php"?>
<?php include "head.php"?>
<?php 
	// checking if a user is logged in
	if (!isset($_SESSION['user_id'])) {
		//header('Location: index.php');
	}

	$user_list = '';
	$search = '';

	// getting the list of users
	if ( isset($_GET['search']) ) {
		$search = mysqli_real_escape_string($con, $_GET['search']);
		$query = "SELECT * FROM customers WHERE (username LIKE '%{$search}%'  OR email LIKE '%{$search}%')  ORDER BY username";					
	} else {
		$query = "SELECT * FROM customers   ORDER BY username";
	}
	
	$users = mysqli_query($con, $query);

	verify_query($users);

	while ($user = mysqli_fetch_assoc($users)) {
		$user_list .= "<tr>";
		$user_list .= "<td>{$user['id']}</td>";
		$user_list .= "<td>{$user['username']}</td>";
		$user_list .= "<td>{$user['email']}</td>";
		$user_list .= "<td><a href=\"modify-user.php?user_id={$user['id']}\">Edit</a></td>";
		$user_list .= "<td><a href=\"delete-user.php?user_id={$user['id']}\" 
						onclick=\"return confirm('Are you sure?');\">Delete</a></td>";
		$user_list .= "</tr>";
	}
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Users</title>
	<link rel="stylesheet" href="css/main.css">
</head>
<body>
	
<header>
        <?php include "header.php"?>
    </header>
    <section class="row">
        <div class="col-2">
            <?php include "sidebar.php"?>
        </div>
        <div class=" col-10 container">
			<nav class="mt-2" aria-label="breadcrumb">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.php">Home</a></li>
					<li class="breadcrumb-item active" aria-current="page">Customers</li>
				</ol>
			</nav>

			<div class="search">
				<form action="users.php" method="get">
					<p>
						<input type="text" name="search" id="" placeholder="Type First Name, Last Name or Email Address and Press Enter" value="<?php echo $search; ?>" required autofocus>
					</p>
				</form>
			</div>
			
				<table class="table">
					<tr>
						<th>ID</th>
						<th>Username</th>
						<th>Email</th>
						<th>Edit</th>
						<th>Delete</th>
						
					</tr>

					<?php echo $user_list; ?>

				</table>
		
        </div>
    
       
        
    </section>
    
	<main class="container col">
    	
		
		
		
	</main>
</body>
</html>