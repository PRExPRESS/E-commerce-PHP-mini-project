<?php 
session_start();
$_SESSION = array();//set the $_SESSION to an empty array
session_destroy();//destroy the session
header("Location:index.php");//redirection
?>