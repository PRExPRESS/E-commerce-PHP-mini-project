<?php session_start(); ?>
<?php include "connection.php"?>
<?php include "functions.php"?>
<?php include "head.php"?>
<?php 

	$errors = array();
	$first_name = '';
	$last_name = '';
	$email = '';
	$password = '';

	if (isset($_POST['submit'])) {
		
		$first_name = $_POST['first_name'];
		$last_name = $_POST['last_name'];
		$email = $_POST['email'];
		$password = $_POST['password'];

		
		

		// checking email address
		if (!is_email($_POST['email'])) {
			$errors[] = 'Email address is invalid.';
		}
        // checking if email address already exists
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $query = "SELECT * FROM user WHERE email = '{$email}' LIMIT 1";

        $result_set = mysqli_query($con, $query);

        if ($result_set) {
            if (mysqli_num_rows($result_set) == 1) {
                $errors[] = 'Email address already exists';
            }
        }
        if (empty($errors)) {
			 //no errors found... adding new record
			 $first_name = mysqli_real_escape_string($con, $_POST['first_name']);
			 $last_name = mysqli_real_escape_string($con, $_POST['last_name']);
			 $password = mysqli_real_escape_string($con, $_POST['password']);
             $hashed_paswd = sha1($password);
             
			
		

			$query ="INSERT INTO user(";
            $query .="email, first_Name, last_Name, password";
            $query .=") VALUES (";
            $query .="'{$email}','{$first_name}','{$last_name}','{$hashed_paswd}'";
            $query .=")";
        

			$result = mysqli_query($con, $query);

			if ($result) {
				// query successful... redirecting to users page
				header('Location: adduser.php');
			} else {
				$errors[] = 'Failed to add the new record.';
			}


		}

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Adduser</title>
	<link rel="stylesheet" href="css/main.css">
</head>
<body>
	<header>
		
		
	</header>
    

	<main>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="home.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Add User</li>
            </ol>
        </nav>
    
        <?php 

			if (!empty($errors)) {
				echo '<div class="errmsg">';
				echo '<b>There were error(s) on your form.</b><br>';
				foreach ($errors as $error) {
					echo '- ' . $error . '<br>';
				}
				echo '</div>';
			}

		 ?>
        <form action="adduser.php" method="post"class="">
		<p>
				<label for="">First Name:</label>
				<input type="text" class="form-control" name="first_name" value="">
			</p>

			<p>
				<label for="">Last Name:</label>
				<input type="text"class="form-control" name="last_name"  value="">
			</p>

			<p>
				<label for="">Email Address:</label>
				<input type="text"class="form-control" name="email"  value="">
			</p>

			<p>
				<label for="">New Password:</label>
				<input type="password" class="form-control" name="password">
			</p>

			<p>
				<label for="">&nbsp;</label>
				<button type="submit" name="submit">Save</button>
                <button type="reset" >Reset</button>
			</p>
        </form>

	</main>
</body>
</html>