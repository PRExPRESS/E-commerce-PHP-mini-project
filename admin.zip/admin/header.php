<?php
include 'head.php';
$_SESSION['user_name']="Pasindu" ;
$siteName="Shop"; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="CSS/h_style.css">
    <style>
        .bo{
           /* background-image: url("images/logo.png");*/
            width:200px;
            height:200px;
        }
    </style>
    
</head>
<body>
    
        <!--Start nav bar-->
        <nav class="navbar navbar-expand-lg bg-dark navbar-dark ">
            <a class="navbar-cream" href="index.php">ADMIN</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse " id="collapsibleNavbar">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="cart.php"><i class="fas fa-home"></i><?php echo " ".$msg=0; ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="cart.php"></i><?php echo " ". $siteName; ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="cart.php"><li><i class="fas fa-comment-alt"></i><?php echo " ".$msg=0; ?></li></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="admin.php"><?php echo $_SESSION['user_name']; ?></a>
                    </li>
                    <li class="nav-item">
                        <?php if(isset($_SESSION['user_name']) && !empty($_SESSION['user_name']))
                        {
                        ?>
                        <a class="nav-link" href="logout.php">Sign out</a>
                        <?php }else{?>
                        <a class="nav-link" href="login.php">Sign in</a>
                        <?php } ?>
                    </li>    
                </ul>
            </div>  
        </nav>
</body>
</html>