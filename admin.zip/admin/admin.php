<?php session_start(); ?>
<?php include "connection.php";
include "head.php";
include "functions.php";
?>

<?php 
	// checking if a user is logged in
	/*if (!isset($_SESSION['user_name'])) {
		header('Location: index.php');
	}*/

	$user_list = '';
	$search = '';

	// getting the list of users
	if ( isset($_GET['search']) ) {
		$search = mysqli_real_escape_string($con, $_GET['search']);
		$query = "SELECT * FROM user WHERE (first_name LIKE '%{$search}%' OR last_name LIKE '%{$search}%' OR email LIKE '%{$search}%')  ORDER BY first_name";					
	} else {
		$query = "SELECT * FROM user";
	}
    $users = mysqli_query($con, $query);
    verify_query($users);
    while ($user = mysqli_fetch_assoc($users)) {
        $user_list .= "<tr>";
        $user_list .= "<td>{$user['id']}</td>";
        $user_list .= "<td>{$user['email']}</td>";
        $user_list .= "<td>{$user['first_Name']}</td>";
        $user_list .= "<td>{$user['last_Name']}</td>";
        $user_list .= "<td>{$user['last_login']}</td>";
        $user_list .= "<td><a href=\"modify-user.php?user_id={$user['id']}\">Edit</a></td>";
        $user_list .= "<td><a href=\"delete-user.php?user_id={$user['id']}\" 
                        onclick=\"return confirm('Are you sure?');\">Delete</a></td>";
        $user_list .= "</tr>";
    }
	
	

	

	
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Users</title>
	<link rel="stylesheet" href="css/main.css">
</head>
<body>
        <header>
            <?php include "header.php"?>
        </header>
        <section class="row">
            <div class="col-2">
                <?php include "sidebar.php"?>
            </div>
            <div class="col-10 p-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="home.php">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Admin</li>
                </ol>
            </nav>
        <main>
        

            <div class="search">
                <form action="admin.php" method="get">
                    <div>
                    <input type="text" class=" " name="search" id="" placeholder="Type First Name, Last Name or Email Address and Press Enter" value="<?php echo $search; ?>" required autofocus>
                    <button type="submit"name="srch"  class=" mb-1 btn btn-primary">Search</button>
                    </div>

                </form>
            </div>



		    <table class="table">
                <tr>
                    <th>ID</th>
                    <th>Email</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Last Login</th>
                    <th>Edit</th>
                    <th>Delete</th>
                    
                </tr>

                <?php echo $user_list; ?>

		    </table>
            <div class="float-right">
                <a href="adduser.php"><button type="button" class="btn btn-primary">+ADD Users</button></a>
            </div>
		
		
	    </main>
            
        
        
            
    </section>
        
</body>
</html>