<?php
    include 'head.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>side navigation</title>
    <link rel="stylesheet" href="CSS/main.css">
    
</head>
<body>
    <nav class=" col bg-dark position-relative side">
        
        <ul class="navbar-nav">
            <li class="nav-item mb-3">
                <a class="nav-link" href="cart.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            </li>
            
           <!-- <li class=" mb-3 nav-item">
                <a href="#"><i class="fas fa-copy"></i> Pages</a>
            </li>-->
            <li class=" mb-3 nav-item">
                <a href="#"><i class="fas fa-comment-alt"></i> Comments</a>
            </li>
            <li class=" mb-3 nav-item">
                <a href="orders.php"><i class="fas fa-shopping-cart"></i> Orders</a>
            </li>
            <li>
                <a href="#"><i class="fas fa-users"></i> Customers</a>
            </li>
            <li class=" mb-3 nav-item">
                <a href="#"><i class="fas fa-cogs"></i> Settings</a>
            </li>
            <li class=" mb-3nav-item">
                <a href="#"><i class="fas fa-chart-line"></i> Status</a>
            </li>
            <li class=" mb-3 nav-item">
                <a href="addproduct.php"><i class="fas fa-box-open"></i>ADD Products</a>
            </li>
            <li class=" mb-3 nav-item">
                <a href="#"><i class="fas fa-chart-bar"></i> Analytics</a>
            </li>
        </ul>
    </nav>

    
    
</body>
</html>