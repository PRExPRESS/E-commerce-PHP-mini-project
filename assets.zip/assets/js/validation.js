function validation() {
    var x = document.forms["myForm"]["fname"].value;
    var paswd = document.forms["myForm"]["paswd"].value;
    var popup = document.getElementById("myPopup");
    var popupP = document.getElementById("myPopupP");
    var model = document.getElementById("cont");
    
    if (x == "") {
        popup.classList.toggle("show");
        return false;
    }
    if (paswd == "") {
        popup.classList.toggle("show");
        return false;
    }
    window.onclick = function(event) {
        if (event.target == model) {
            popup.style.display = "none";
        }
    }
}
//=============================================
function formVal(){
    var un= document.getElementById("uname").value;
    var e= document.getElementById("email").value;
    var pass= document.getElementById("pass").value;
    var conpass= document.getElementById("c_pass").value;
    

    if(un==""){
        document.getElementById("fv").innerHTML="Field must be filled*";
        return false;
    }

    
    if(e==""){
        document.getElementById("ev").innerHTML="Field must be filled*";
        return false;
    }

    if(pass==""){
        document.getElementById("pv").innerHTML="Field must be filled*";
        return false;
    }

    if(conpass==""){
        document.getElementById("pcv").innerHTML="Field must be filled*";
        return false;
    }else{
        if(pass != conpass){
            document.getElementById("pcv").innerHTML="Password not match*";
            //console.write("password mis match");
           // alert("Password not match");
            return false;
            
        }
        
    }


    /*======================Email validation==============*/
    var x=document.forms["signup"]["email"].value;
    var mailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    var at = x.indexOf("@");
    var dot= x.indexOf(".");
    if(x.match(mailformat)){
        if(at<1 || dot<at+2 || dot+2>=x.length){
            document.getElementById("ev").innerHTML="Not a valied email**";
            return false;
        }
    }
    else{
        document.getElementById("ev").innerHTML="Email format not valied**";
        return false;
    }

    /*===================Passsword confirm=======*/
    
    

}
var myInput = document.getElementById("pass");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");

myInput.onfocus=function(){
    document.getElementById("hint").style.display = "block";
}
myInput.onblur=function(){
    document.getElementById("hint").style.display = "none";
}
myInput.onkeyup=function(){
    var lowerCaseLetters = /[a-z]/g;
    if(myInput.value.match(lowerCaseLetters)){
        letter.classList.remove("invalid");
        letter.classList.add("valid");
    }
    else{
        letter.classList.remove("valid");
        letter.classList.add("invalid");
    }

    var upperCaseLetters = /[A-Z]/g;
    if(myInput.value.match(upperCaseLetters)){
        capital.classList.remove("invalid");
        capital.classList.add("valid");
    }
    else{
        capital.classList.remove("valid");
        capital.classList.add("invalid");
    }

    var numbers = /[0-9]/g;
    if(myInput.value.match(numbers)){
        number.classList.remove("invalid");
        number.classList.add("valid");
    }
    else{
        number.classList.remove("valid");
        number.classList.add("invalid");
    }

    
    if(myInput.value.length >=8){
        length.classList.remove("invalid");
        length.classList.add("valid");
    }
    else{
        length.classList.remove("valid");
        length.classList.add("invalid");
    }
}
function btnDis(){
    var chk = document.getElementById("aggry").value;
    if(chk !=null){
        document.getElementById("submit").disabled=false;   
    }
    else{
        document.getElementById("submit").disabled=true;

    }
}
function submitDisable(){
   // document.getElementById("submit").disabled=true;
}