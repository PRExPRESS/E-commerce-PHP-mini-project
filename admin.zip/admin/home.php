<?php
session_start();
include 'head.php';

if(!isset($_SESSION['user_id'])){
    header('Location:index.php');
}
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="CSS/main.css">
</head>
<body>
    <header>
        <?php include "header.php"?>
    </header>
    <section class="row">
        <div class="col-2">
            <?php include "sidebar.php"?>
        </div>
        <div class="col-10">
            <?php include "dashboard.php"?>
        </div>
        
    </section>
    <article>
        
    </article>
</body>
</html>