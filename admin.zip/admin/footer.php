<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
   .main ul{
      list-style:none;
    }
  .main li{
      float:left;
    }

  </style>
</head>
<body>
  <ul class="main">
    <li>Home</li>
    <li>Shop
      <Ul class="wrap">
        <li>Laptop</li>
        <li>PC</li>
        <li>Accesseries</li>
      </Ul>
    </li>
    <li>Contact</li>
  </ul>
</body>
</html>