<?php 
session_start();
include "connection.php" ?>
<?php 
    //form submission check
    if(isset($_POST['submit'])){
        $errors = array();
        //check if the username password entered
        if(!isset($_POST['username']) || strlen(trim($_POST['username']))<1){
            $errors[] = 'Username is Missing /Invalied';
        }
        if(!isset($_POST['passwd']) || strlen(trim($_POST['passwd']))<1){
            $errors[] = 'passwd is Missing /Invalied';
        }

        //check if there any error
        if(empty($errors)){
            //save username password into variabel
            $username = mysqli_real_escape_string($con,$_POST['username']);
            $passwd = mysqli_real_escape_string($con,$_POST['passwd']);
            $hashed_passwd = sha1($passwd);
            
            //prepare database query
            $query = "SELECT * FROM user 
                        WHERE email ='{$username}'
                        AND password = '{$hashed_passwd}' 
                        LIMIT 1 ";
            $result_set = mysqli_query($con,$query);

            //check if  the user is valied
            if($result_set){
                //query succsesfull
                if(mysqli_num_rows($result_set)==1){
                    //valid user found
                   $user =mysqli_fetch_assoc($result_set);
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['first_name'] = $user['first_Name'];
                    //redirect to home page
                    header('Location:home.php');
                }else{
                    //username and password invalid
                    $errors[] = 'Invalid Username or Password';
                }
            }else{
                $errors[] = 'Database query faild';
            }
            
            //if not, display the error

        }
    }
?>
<?php 
if(!empty($errors)){
    echo '<script> alert("Username or Password Incorrect!")</script>'; 
    

}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
    <div class="col-5 mx-auto mt-9 mb-5 border">
        <span class="font "><center>Admin Login</center></span>
    <form action="index.php" method="post">
        <div class="form-group">
            <label for="exampleInputEmail1">Email address*</label>
            <input type="email" class="form-control" id="exampleInputEmail1" name="username" aria-describedby="emailHelp" placeholder="Enter email">
            
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Password*</label>
            <input type="password" name="passwd" class="form-control" id="exampleInputPassword1" placeholder="Password">
        </div>
        <div class="form-check">
            <input type="checkbox" class="form-check-input" id="exampleCheck1" name="passwd">
            <label class="form-check-label" for="exampleCheck1">Check me out</label>
        </div>
        <button type="submit" name="submit" class="btn btn-primary btn-block mb-3">Submit</button>
    </form>
    </div>
   
   
</body>
</html>
