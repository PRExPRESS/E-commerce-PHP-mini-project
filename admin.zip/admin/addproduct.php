<?php 
include 'head.php';
include 'connection.php';
$errors = array();
if(isset($_POST['submit'])){
    $errors = array();
    //image
    $file_name = $_FILES['image']['name'];
    $file_type = $_FILES['image']['type'];
    $file_size = $_FILES['image']['size'];
    $temp_name = $_FILES['image']['tmp_name'];

    //loction
    $upload_to = 'images/';

    //checking img type
    
    //check file size
    if($file_size > 1000000){
        $errors[] = 'File size too much.. >1MB.';
    }

    //check if the fields
    if(!isset($_POST['model']) || strlen(trim($_POST['model']))<1){
        $errors[] = 'model is Missing /Invalied';
    }
    if(!isset($_POST['disc']) || strlen(trim($_POST['disc']))<1){
        $errors[] = 'discription is Missing /Invalied';
    }
    if(!isset($_POST['price']) || strlen(trim($_POST['price']))<1){
        $errors[] = 'discription is Missing /Invalied';
    }
    if(!isset($_POST['qty']) || strlen(trim($_POST['qty']))<1){
        $errors[] = 'QTY is Missing /Invalied';
    }
    
    if (empty($errors)) {
        $model =$_POST['model'];
        $disc = $_POST['disc'];
        $price = $_POST['price'];
        $qty = $_POST['qty'];
        $stat =$_POST['stat'];
        //save image file
        $file_uploaded = move_uploaded_file($temp_name, $upload_to . $file_name );
        

      //INSERT INTO QUERY 
      $query ="INSERT INTO product(";
      $query .="modal, disc, price, qty, status, img ";
      $query .=") VALUES (";
      $query .="'{$model}','{$disc}','{$price}','{$qty}','{$stat}','{$file_name}'";
      $query .=")";
      $result_set = mysqli_query($con,$query);
      if($result_set){
        echo '<script> alert(" Product add Successfully!")</script>';
      }else {
        
        echo '<script> alert("Database Query Error!")</script>';
      }
      
    }else {
      echo '<script> alert("Field must be filed!")</script>';
    }  
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add product</title>
</head>
<body>
<header>
        <?php include "header.php"?>
    </header>
    <section class="row">
        <div class="col-2">
            <?php include "sidebar.php"?>
        </div>
        
        <div class=" col-10 container ">
        <!-------------bBreadCrumb--------------->
        <nav class="mt-2" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Add Product</li>
            </ol>
        </nav>


        <div class="card mt-2 p-3">
            <form action="addproduct.php" method="post" enctype="multipart/form-data">
                <table class="table table-boarded">
                    <tr>
                        <th>Model</th>
                        <td><input class="form-control" type="text" name="model" id=""> </td>
                    </tr>
                    <tr>
                        <th>Discription</th>
                        <td><textarea class="form-control" name="disc" id="" cols="30" rows="2"></textarea></td>
                    </tr>
                    <tr>
                        <th>Price</th>
                        <td><input class="form-control" type="text" name="price" id=""> </td>
                    </tr>
                    <tr>
                        <th>Qty</th>
                        <td><input class="form-control" type="text" name="qty" id="">  </td>
                    </tr>
                    <tr>
                        <th>Image</th>
                        <td><input class="form-control"  type="file" name="image" id=""> </td>
                    </tr>
                    <tr>
                        <th>Status</th>
                        <td>
                        <select name="stat" class=" custom-select" required>
                                <option value="available">Available</option>
                                <option value="sold">SoldOut</option>
                                
                            </select>
                        </td>
                    </tr>
                    <tr>
                    </tr>
                </table>
                <button type="submit" name="submit" class=" float-right btn btn-primary">Add Product</button>
            </form>

        </div>  
    </div>
        
    
       
        
    </section>
    
</body>
</html>